# GpsTracker
# IDE: Android Studio 3.4.1.
# Language : JAVA
# API : Room
# Android Application

An android application witch tracks user movements and stores it on SQLite DB
